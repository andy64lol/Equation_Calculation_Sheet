import ecs

# ----------------------------
# Load ECS / ECSP sheets
# ----------------------------
ecs.add_sheet("constants")   # loads constants.ecs
ecs.add_sheet("physics")     # loads physics.ecsp
ecs.add_sheet("main")        # loads main.ecs

# ----------------------------
# Access basic ECS variables
# ----------------------------
print("x =", ecs.get("x"))           # 48
print("x2 =", ecs.get("x2"))         # solved quadratic
print("r1 =", ecs.get("r1"))         # 2
print("x3 =", ecs.get("x3"))         # 4
print("a =", ecs.get("a"))           # 2
print("b =", ecs.get("b"))           # 2304
print("c1 =", ecs.get("c1"))         # 1.23e10
print("d =", ecs.get("d"))           # -4
print("e =", ecs.get("e"))           # 8
print("f =", ecs.get("f"))           # ≈0.33

# ----------------------------
# Access ECSP block variables
# ----------------------------
print("spring F =", ecs.get("spring.F"))                 # 20
print("spring K =", ecs.get("spring.K"))                 # 4
print("spring extension =", ecs.get("spring.L_final") - ecs.get("spring.L_init"))  # 5
print("gas v2 =", ecs.get("gas.v2"))                     # solved value
print("ohm v =", ecs.get("electricity.v"))
print("kinematics v =", ecs.get("motion.v"))
print("energy KE =", ecs.get("energy.KE"))
print("projectile R =", ecs.get("projectile.R"))
print("circular F =", ecs.get("circular.F"))
print("workpower P =", ecs.get("workpower.P"))

# ----------------------------
# Access imported ECS constants
# ----------------------------
print("gravity =", ecs.get("gravity"))   # 9.8
print("pi =", ecs.get("pi"))             # 3.14159

# ----------------------------
# Evaluate functions defined in .ecs files
# ----------------------------
print("f(4, 9) =", ecs.evaluate("f", x=4, y=9))        # 26: 2 * (9 + 4)
print("g(3) =", ecs.evaluate("g", a=3))                # 8: 3 + 5 (default b=5)
print("g(3, 10) =", ecs.evaluate("g", a=3, b=10))      # 13: 3 + 10 (override default)
print("h(5) =", ecs.evaluate("h", z=5))                # 6: 5 + 1
